#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <string.h>
#include "adj_matrix.h"

bool outOfBoudaries(int vertex) {
    if(vertex >= maxSize || vertex < 0) return true;
    return false;
}

Graph* createGraphMatrix(int* error) {
    Graph* g = malloc(sizeof(Graph));

    if(g == NULL) {
        *error = 1;
        return NULL;
    }

    g->currSize = 0;

    for (int i = 0; i < maxSize; i++) {
        for (int j = 0; j < maxSize; j++) {
            g->edges[i][j].proximity = -1;
            g->edges[i][j].areFriends = strangers;
        }
    }

    *error = 0;
    return g;
}

void destroyGraphMatrix(Graph* g, int* error) {
    free(g);
    return;
}

void printMatrix(Graph* g, int debug) {
    if(debug) 
        printf("size: %d\n\n", g->currSize);

    for(int i = 0; i < g->currSize; i++) {
        for(int j = 0; j < g->currSize; j++) {
            printf("%d\t", g->edges[i][j].proximity);
        }
        printf("\n");
    }

    printf("\n");
    for(int i = 0; i < g->currSize; i++) {
        for(int j = 0; j < g->currSize; j++) {
            printf("%d\t", g->edges[i][j].areFriends);
        }
        printf("\n");
    }

}

void addEdgeMatrix(Graph* g, int from, int to, int proximity, int* error) {    
    if(g == NULL || outOfBoudaries(from) || outOfBoudaries(to)) {
        *error = 1;
        return;
    }

    g->edges[from][to].proximity = proximity;
    g->edges[to][from].proximity = proximity;

    *error = 0;
    return;
}

void removeEdgeMatrix(Graph* g, int from, int to, int* error) {
    if(g == NULL || outOfBoudaries(from) || outOfBoudaries(to)) {
        *error = 1;
        return;
    }

    g->edges[from][to].proximity = noEdge;
    g->edges[to][from].proximity = noEdge;

    *error = 0;
    return;
}

void bfs(Graph* g, int source) {
    memset(g->distance, -1, maxSize);
    memset(g->visited, white, maxSize);

    Queue* q = createQueue();

    insertQueue(q, source, 0);
    g->distance[source] = 0;

    while (!isEmptyQueue(q)) {
        Pair p = popQueue(q);
        
        int u = p.first;
        int w = p.second;

        for(int i = 0; i < g->currSize; i++) {
            if(g->edges[i][u].areFriends == friends && g->visited[i] == white) {
                insertQueue(q, i, w + 1);
                g->distance[i] = w + 1;
                g->visited[i] = gray;
            }
        }

        g->visited[u] = black;
    }

    return;    
}

int degreeIn(Graph* g, int vertex, int* error) {
    if(g == NULL || outOfBoudaries(vertex)) {
        *error = 1;
        return -1;
    }

    int deg = 0;

    for(int i = 0; i < maxSize; i++) {
        if(g->edges[i][vertex].proximity != noEdge)
            deg++;
    }

    *error = 0;
    return deg;
}

int degreeOut(Graph* g, int vertex, int* error) {
    if(g == NULL || outOfBoudaries(vertex)) {
        *error = 1;
        return -1;
    }

    int deg = 0;

    for(int i = 0; i < maxSize; i++) {
        if(g->edges[vertex][i].proximity != noEdge)
            deg++;
    }

    *error = 0;
    return deg;
}